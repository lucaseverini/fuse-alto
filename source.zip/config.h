// The configured options and settings for fuse-alto
#if !defined(_CONFIG_H_)
#define _CONFIG_H_

#define FUSE_ALTO_VERSION "0.3.1"
#define FUSE_ALTO_VERSION_MAJOR 0
#define FUSE_ALTO_VERSION_MINOR 3
#define FUSE_ALTO_VERSION_PATCH 1
#define FUSE_ALTO_VER (0 * 65536 + 3 * 256 + 1)

#if defined(NDEBUG)
#define BUILD_TYPE "Release"
#else
#define BUILD_TYPE "Debug"
#endif

#endif // !defined(_CONFIG_H_)
